import express from "express";
import cors from "cors";
import UserRoute from "./routes/UserRoute.js";
import ProfileRoute from "./routes/ProfileRoute.js";
import MessageRoute from "./routes/MessageRoute.js";
import PostRoute from "./routes/PostRoute.js";
import LikeRoute from "./routes/LikeRoute.js";
import db from "./config/Database.js";
import FileUpload from "express-fileupload";
// import mysql from "mysql";
// import multer from "multer";

const app = express();
// const uploads = multer({dest: __dirname + "/uploads"}); 
app.use(cors());
app.use(express.json());
app.use(FileUpload());
app.use(express.static("public"));
app.use(UserRoute);
app.use(ProfileRoute);
app.use(MessageRoute);
app.use(PostRoute);
app.use(LikeRoute);

// app.post("/uploads", uploads.array("files"), (req, res) =>
// {
//     
// })

// app.post("/login", (req, res) => {
//   const sql = "SELECT * FROM users WHERE username = ? and password = ?";
//   db.query(sql, [req.body.username, req.body.password], (err, result) => {
//     if (err) return res.json({ Messages: "Error inside server" });
//     if (result.length > 0) {
//       return res.json({ Login: true });
//     } else {
//       return res.json({ Login: false });
//     }
//   });
// });

app.listen(5000, () => console.log("Server up and running..."));
