import { Sequelize } from "sequelize";
import db from "../config/Database.js";
import Post from "./PostModel.js";
import User from "./UserModel.js";

const { DataTypes } = Sequelize;

const Like = db.define(
  "likes",
  {
    postId: DataTypes.INTEGER,
    userId: DataTypes.INTEGER
  },
  {
    freezeTableName: true,
  }
);
User.hasMany(Like);
Post.hasMany(Like);
Like.belongsTo(User);
Like.belongsTo(Post);

export default Like;

(async () => {
  await db.sync();
})();
