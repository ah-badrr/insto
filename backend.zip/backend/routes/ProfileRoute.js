import express from "express";
import { getProfiles, createProfile, getProfileById, updateProfile, deleteProfile } from "../controllers/ProfileController.js";

const router=express.Router();

router.get("/profiles", getProfiles);
router.get("/profiles/:id", getProfileById);
router.post("/profiles", createProfile);
router.patch("/profiles/:id", updateProfile);
router.delete("/profiles/:id", deleteProfile);

export default router;
