import express from "express";
import { getLikes, createLike, getLikeById, updateLike, deleteLike } from "../controllers/LikeController.js";

const router = express.Router();

router.get("/likes", getLikes);
router.get("/likes/:post&&:user", getLikeById);
router.post("/likes", createLike);
router.patch("/likes/:id", updateLike);
router.delete("/likes/:post&&:user", deleteLike);

export default router;
