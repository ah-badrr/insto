<?php

require '../config.php';

$username = $_POST['username'];
$password = $_POST['password'];

$result = $conn->query("INSERT INTO user VALUES (default, '$username', '$password', '')");

$response = [];

if ($result) {
    $code = 300;
    $message = 'Register Succesfull';
} else {
    $code = 404;
    $message = 'Register failed!';
}

echo json_encode([
    'Response' => $code,
    'Message' => $message
]);
