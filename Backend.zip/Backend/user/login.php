<?php
require '../config.php';

$username = $_POST['username'];
$password = $_POST['password'];
$token =  md5($username . $password);

$result = $conn->query("UPDATE user SET token = '$token' WHERE username = '$username' AND password = '$password'");
$user = $conn->query("SELECT * FROM user WHERE token = '$token'")->fetch_assoc();
if ($result) {
    $code = 'success';
    $message = 'Login Succesfull';
    $id = $user['id'];
    session_start();
    $_SESSION['login'] = $id;
} else {
    $code = 'failed';
    $message = 'Login failed!';
}

echo json_encode([
    'Response' => $code,
    'Message' => $message,
    'Token' =>  $token,
    'Session' => $id
]);
