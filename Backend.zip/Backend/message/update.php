<?php
require '../config.php';
// header("Access-Control-Allow-Origin: http://localhost:3000");


$mid = $_GET['mid'];
$message = $_POST['message'];
session_start();
if ($_SESSION['login']) {
    $id = $_SESSION['login'];
    $result = $conn->query("UPDATE messages SET message='$message' WHERE id = '$mid'");
    if ($result) {
        $code = 'success';
        $data = [
            'message' => $message,
        ];
    } else {
        $code = 'failed';
    }
} else {
    $code = 'login';
}


echo json_encode([
    'Response' => $code,
    'Session' => $_SESSION['login'],
    'Data' => $data
]);
