<?php
require '../config.php';
header("Access-Control-Allow-Origin: http://localhost:3000");

session_start();
if ($_SESSION['login']) {
    $id = $_SESSION['login'];
    $result = $conn->query("SELECT * FROM messages");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        };
        $code = 'success';
    } else {
        $code = 'failed';
    }
} else {
    $code = 'login';
}


echo json_encode([
    'Response' => $code,
    'Session' => $_SESSION['login'],
    'Data' => $data
]);
