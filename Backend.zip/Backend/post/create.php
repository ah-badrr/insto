<?php
require '../config.php';
header("Access-Control-Allow-Origin: http://localhost:3000");

$user_id = $_POST['user_id'];
$caption = $_POST['caption'];
$nama_file = $_FILES['image']['name'];
$tipe_file = $_FILES['image']['type'];
$tmp_file = $_FILES['image']['tmp_name'];

$path = "../img/" . $nama_file;
session_start();
if ($_SESSION['login']) {
    $id = $_SESSION['login'];
    move_uploaded_file($tmp_file, $path);
    $result = $conn->query("INSERT INTO post values(default, $user_id, '$nama_file', '$caption')");
    if ($result) {
        $code = 'Success';
        $data = [
            'user_id' => $user_id,
            'image' => $nama_file,
            'caption' => $caption,
        ];
    }
} else {
    $code = 'login';
}


echo json_encode([
    'Response' => $code,
    'Session' => $_SESSION['login'],
    'Data' => $data
]);
